const form = document.getElementById('retirement-form');
const resultsDiv = document.getElementById('results');
const futureValueEl = document.getElementById('future-value');
const neededValueEl = document.getElementById('needed-value');
const resultMessageEl = document.getElementById('result-message');
const chartCanvas = document.getElementById('savings-chart');

let savingsChart = null;

const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Get values from form
    const currentAge = parseInt(document.getElementById('current-age').value);
    const retirementAge = parseInt(document.getElementById('retirement-age').value);
    const currentSavings = parseFloat(document.getElementById('current-savings').value);
    const monthlyContribution = parseFloat(document.getElementById('monthly-contribution').value);
    const desiredIncome = parseFloat(document.getElementById('desired-income').value);
    const returnRate = parseFloat(document.getElementById('return-rate').value) / 100;

    // --- Calculations ---
    const yearsToRetirement = retirementAge - currentAge;
    if (yearsToRetirement <= 0) {
        alert("A idade de aposentadoria deve ser maior que a idade atual.");
        return;
    }

    const monthlyReturnRate = Math.pow(1 + returnRate, 1/12) - 1;

    // Future Value of current savings
    const fvCurrentSavings = currentSavings * Math.pow(1 + returnRate, yearsToRetirement);
    
    // Future Value of monthly contributions
    const totalMonths = yearsToRetirement * 12;
    let fvContributions = 0;
    if (monthlyReturnRate > 0) {
        fvContributions = monthlyContribution * ((Math.pow(1 + monthlyReturnRate, totalMonths) - 1) / monthlyReturnRate);
    } else { // Handle zero interest rate case
        fvContributions = monthlyContribution * totalMonths;
    }

    const totalSavingsAtRetirement = fvCurrentSavings + fvContributions;

    // Nest egg needed for desired income (using 4% rule as a proxy)
    // The annual income needed is desiredIncome * 12
    // Required capital = Annual Income / Withdrawal Rate (4% = 0.04)
    const neededNestEgg = (desiredIncome * 12) / 0.04; 

    // --- Display Results ---
    futureValueEl.textContent = formatCurrency(totalSavingsAtRetirement);
    neededValueEl.textContent = formatCurrency(neededNestEgg);

    // --- Update Message ---
    resultMessageEl.classList.remove('success', 'warning');
    if (totalSavingsAtRetirement >= neededNestEgg) {
        resultMessageEl.textContent = 'Parabéns! Você está no caminho certo para atingir seus objetivos de aposentadoria.';
        resultMessageEl.classList.add('success');
    } else {
        const difference = neededNestEgg - totalSavingsAtRetirement;
        resultMessageEl.textContent = `Atenção! Faltam ${formatCurrency(difference)} para você atingir seu objetivo. Considere aumentar sua contribuição mensal ou ajustar suas expectativas.`;
        resultMessageEl.classList.add('warning');
    }

    // --- Update Chart ---
    const chartData = {
        labels: [],
        datasets: [{
            label: 'Patrimônio Acumulado',
            data: [],
            backgroundColor: 'rgba(52, 152, 219, 0.2)',
            borderColor: 'rgba(52, 152, 219, 1)',
            borderWidth: 2,
            fill: true,
            tension: 0.1
        }]
    };
    
    let projectionValue = currentSavings;
    for (let i = 0; i <= yearsToRetirement; i++) {
        const age = currentAge + i;
        chartData.labels.push(age);
        
        // Calculate projection for each year
        let yearProjection = currentSavings * Math.pow(1 + returnRate, i);
        if (returnRate > 0) {
            yearProjection += (monthlyContribution * 12) * ((Math.pow(1 + returnRate, i) - 1) / returnRate);
        } else {
            yearProjection += (monthlyContribution * 12) * i;
        }

        chartData.datasets[0].data.push(yearProjection);
    }

    if (savingsChart) {
        savingsChart.destroy();
    }
    
    savingsChart = new Chart(chartCanvas, {
        type: 'line',
        data: chartData,
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatCurrency(value);
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                label += formatCurrency(context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            }
        }
    });

    resultsDiv.classList.remove('hidden');
    resultsDiv.scrollIntoView({ behavior: 'smooth' });
});

